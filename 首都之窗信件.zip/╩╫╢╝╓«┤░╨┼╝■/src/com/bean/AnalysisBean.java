package com.bean;

public class AnalysisBean
{
private String Name;
private String Num;
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getNum() {
	return Num;
}
public void setNum(String num) {
	Num = num;
}

}
