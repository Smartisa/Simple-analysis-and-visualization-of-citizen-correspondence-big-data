package com.bean;

public class InfoBean {
	private String Id;
	private String Question;
	private String Question_user;
	private String Question_date;
	private String Question_info;
	private String Answer;
	private String Answer_user;
	private String Answer_date;
	private String Answer_info;
	private String Url;
	public String getUrl() {
		return Url;
	}
	public void setUrl(String url) {
		Url = url;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getQuestion_user() {
		return Question_user;
	}
	public void setQuestion_user(String question_user) {
		Question_user = question_user;
	}
	public String getQuestion_date() {
		return Question_date;
	}
	public void setQuestion_date(String question_date) {
		Question_date = question_date;
	}
	public String getQuestion_info() {
		return Question_info;
	}
	public void setQuestion_info(String question_info) {
		Question_info = question_info;
	}
	public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		Answer = answer;
	}
	public String getAnswer_user() {
		return Answer_user;
	}
	public void setAnswer_user(String answer_user) {
		Answer_user = answer_user;
	}
	public String getAnswer_date() {
		return Answer_date;
	}
	public void setAnswer_date(String answer_date) {
		Answer_date = answer_date;
	}
	public String getAnswer_info() {
		return Answer_info;
	}
	public void setAnswer_info(String answer_info) {
		Answer_info = answer_info;
	}

}
